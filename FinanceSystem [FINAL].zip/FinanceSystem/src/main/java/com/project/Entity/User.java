package com.project.Entity;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "user")
public class User{
  
   @Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
   private Long id;
    
   @Column(nullable = false, unique = true, length = 45)
   private String email;
   
   @Column(nullable = false, unique = true, length = 45)
   private String username;
    
   @Column(nullable = false, length = 64)
   private String password;
    
   @Column(name = "first_name", nullable = false, length = 20)
   private String firstName;
    
   @Column(name = "last_name", nullable = false, length = 20)
   private String lastName;
    
   @Column(name = "role", nullable = false, length = 20)
   private String role;
   
   @Column(name = "mobileNumber", nullable = false, length = 20)
   private String mobileNumber;
  
   private boolean accountNonLocked;
   
   private boolean enabled;

   @Column(name = "verificationCode", nullable = true)
   private String verificationCode;

   @JsonIgnore// for removing the bidirectional relationship and Jackson is trying to serialize these relationships, resulting in a circular reference and causing the Infinite recursion (StackOverflowError).
   @OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
   private List<Income> incomes;

   @JsonIgnore
   @OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
   private List<Expense> expenses;
   
   public User() {
	   super();
	   
   }

   
   public User(Long id, String email, String username, String password, String firstName, String lastName, String role,
			String mobileNumber, boolean accountNonLocked, boolean enabled, String verificationCode,
			List<Income> incomes, List<Expense> expenses) {
		super();
		this.id = id;
		this.email = email;
		this.username = username;
		this.password = password;
		this.firstName = firstName;
		this.lastName = lastName;
		this.role = role;
		this.mobileNumber = mobileNumber;
		this.accountNonLocked = accountNonLocked;
		this.enabled = enabled;
		this.verificationCode = verificationCode;
		this.incomes = incomes;
		this.expenses = expenses;
	}

   
   public Long getId() {
	   return id;
   }
   public void setId(Long id) {
	   this.id = id;
   }
   public String getEmail() {
	   return email;
   }
   public void setEmail(String email) {
	   this.email = email;
   }
   public String getUsername() {
	   return username;
   }
   public void setUsername(String username) {
	   this.username = username;
   }
   public String getPassword() {
	   return password;
   }
   public void setPassword(String password) {
	   this.password = password;
   }
   public String getFirstName() {
	   return firstName;
   }
   public void setFirstName(String firstName) {
	   this.firstName = firstName;
   }
   public String getLastName() {
	   return lastName;
   }
   public void setLastName(String lastName) {
	   this.lastName = lastName;
   }
   public String getRole() {
	   return role;
   }
   public void setRole(String role) {
	   this.role = role;
   }
   public String getMobileNumber() {
	   return mobileNumber;
   }
   public void setMobileNumber(String mobileNumber) {
	   this.mobileNumber = mobileNumber;
   }
   public boolean isAccountNonLocked() {
	   return accountNonLocked;
   }

   public void setAccountNonLocked(boolean accountNonLocked) {
	   this.accountNonLocked = accountNonLocked;
   }

   public boolean isEnabled() {
	   return enabled;
   }

   public void setEnabled(boolean enabled) {
	   this.enabled = enabled;
   }

   public String getVerificationCode() {
	   return verificationCode;
   }

   public void setVerificationCode(String verificationCode) {
	   this.verificationCode = verificationCode;
   }

   @Override
   public String toString() {
	   return "User [id=" + id + ", email=" + email + ", username=" + username + ", password=" + password + ", firstName="
			+ firstName + ", lastName=" + lastName + ", role=" + role + ", mobileNumber=" + mobileNumber
			+ ", accountNonLocked=" + accountNonLocked + ", enabled=" + enabled + ", verificationCode="
			+ verificationCode + ", incomes=" + incomes + ", expenses=" + expenses + "]";
   }



   public List<Income> getIncomes() {
	   return incomes;
   }

   public void setIncomes(List<Income> incomes) {
	   this.incomes = incomes;
   }

   public List<Expense> getExpenses() {
	   return expenses;
   }

   public void setExpenses(List<Expense> expenses) {
	   this.expenses = expenses;
   }

}
