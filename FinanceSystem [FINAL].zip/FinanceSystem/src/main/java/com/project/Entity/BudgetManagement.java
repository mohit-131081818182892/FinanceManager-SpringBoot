package com.project.Entity;

import java.math.BigDecimal;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class BudgetManagement {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
	private String categoryName;
    private BigDecimal limitAmount;
    
    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;
	
	public BudgetManagement() {
		super();
		// TODO Auto-generated constructor stub
	}

    public BudgetManagement(Long id, String categoryName, BigDecimal limitAmount, User user) {
		super();
		this.id = id;
		this.categoryName = categoryName;
		this.limitAmount = limitAmount;
		this.user = user;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public BigDecimal getLimitAmount() {
		return limitAmount;
	}

	public void setLimitAmount(BigDecimal limitAmount) {
		this.limitAmount = limitAmount;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "BudgetManagement [id=" + id + ", categoryName=" + categoryName + ", limitAmount=" + limitAmount
				+ ", user=" + user + "]";
	}

	
}
