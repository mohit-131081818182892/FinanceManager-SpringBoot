package com.project.Entity;

public class SecuritySettings {
    private String accessControls;
    private String passwordPolicy;
    private String activityMonitoring;

    public SecuritySettings() {}

    public SecuritySettings(String accessControls, String passwordPolicy, String activityMonitoring) {
        this.accessControls = accessControls;
        this.passwordPolicy = passwordPolicy;
        this.activityMonitoring = activityMonitoring;
    }

    public String getAccessControls() {
        return accessControls;
    }

    public void setAccessControls(String accessControls) {
        this.accessControls = accessControls;
    }

    public String getPasswordPolicy() {
        return passwordPolicy;
    }

    public void setPasswordPolicy(String passwordPolicy) {
        this.passwordPolicy = passwordPolicy;
    }

    public String getActivityMonitoring() {
        return activityMonitoring;
    }

    public void setActivityMonitoring(String activityMonitoring) {
        this.activityMonitoring = activityMonitoring;
    }
}

