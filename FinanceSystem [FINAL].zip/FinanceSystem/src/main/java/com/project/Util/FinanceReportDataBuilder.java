package com.project.Util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.project.Entity.BudgetManagement;
import com.project.Entity.Expense;
import com.project.Entity.Income;
import com.project.Entity.User;

public class FinanceReportDataBuilder {

    // Method to prepare finance report data
    public static Map<String, Object> prepareFinanceReportData(User user, List<Income> incomes, List<Expense> expenses, List<BudgetManagement> budgets) {
        Map<String, Object> data = new HashMap<>();

        // Add user details to the data map
        data.put("user", user);

        // Add income details to the data map
        data.put("incomes", incomes);

        // Add expense details to the data map
        data.put("expenses", expenses);

        // Add budget details to the data map
        data.put("budgets", budgets);

        return data;
    }
}
