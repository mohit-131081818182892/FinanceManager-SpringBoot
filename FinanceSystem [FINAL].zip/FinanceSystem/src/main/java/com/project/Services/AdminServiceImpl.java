package com.project.Services;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import com.project.Entity.Admin; // Assuming you have an Admin entity
import com.project.Entity.User;
import com.project.Repositories.AdminRepository; // Assuming you have an Admin repository
import com.project.Repositories.UserRepository;

import jakarta.mail.internet.MimeMessage;
import net.bytebuddy.utility.RandomString;

@Service
public class AdminServiceImpl implements AdminService {
    
    @Autowired
    private AdminRepository adminRepo;
    
    @Autowired
    private UserRepository userRepo;
    
    @Autowired
    private BCryptPasswordEncoder passwordEncode;
    
    @Autowired
    private JavaMailSender mailSender;
    
    @Override
    public Admin createAdmin(Admin admin, String url) {
        
        admin.setPassword(passwordEncode.encode(admin.getPassword()));
        admin.setRole("ROLE_ADMIN");
        
        admin.setEnabled(false); 
        
        admin.setVerificationCode(UUID.randomUUID().toString());
        
        Admin ad = adminRepo.save(admin);
        
        if (ad != null) {
            sendVerificationMail(admin, url);
        }
        return ad;
    }

    @Override
    public boolean checkEmail(String email) { 
        
        return adminRepo.existsByEmail(email);
    }
    
    
    public void sendVerificationMail(Admin admin, String url) {
        String from = "pranaysureshalame@gmail.com";
        String to = admin.getEmail();
        String subject = "Account Verification";
        String content = "Dear [[name]],<br>"
                + "Please click the link below to verify your registration:<br>"
                + "<h3><a href=\"[[URL]]\" target=\"_self\">ADMINVERIFY</a></h3>"
                + "Thank you,<br>";
        try {
            
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");
            
            helper.setFrom(from,"Admin");
            helper.setTo(to);
            helper.setSubject(subject);
            
            content = content.replace("[[name]]", admin.getFirstName());
            
            String siteUrl = url + "/adminVerify?code=" + admin.getVerificationCode();
            
            content = content.replace("[[URL]]", siteUrl);
            
            helper.setText(content, true);
            
            mailSender.send(message);
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    @Override
    public boolean adminverifyAccount(String code) {
        
        Admin admin = adminRepo.findByVerificationCode(code);
        
        if (admin != null) {
            admin.setAccountNonLocked(true);
            admin.setEnabled(true);
            admin.setVerificationCode(null);
            adminRepo.save(admin);
            return true;
        }
        
        return false;
    }
    
    @Override
    public Admin getAdminByUsername(String username) {
        return adminRepo.findByUsername(username);
    }

    @Override
    public void saveAdmin(Admin admin) {
        adminRepo.save(admin);
    }

	@Override
	public List<User> getAllUsers() {
		return userRepo.findAll();
	}

	@Override
	public User getUserById(Long id) {
		return userRepo.findById(id).orElse(null);
	}

	@Override
	public void saveUser(User existingUser) {
		userRepo.save(existingUser);
		
	}
}
