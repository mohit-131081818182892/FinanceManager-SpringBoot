package com.project.Services;

import java.math.BigDecimal;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.Entity.BudgetManagement;
import com.project.Entity.Expense;
import com.project.Entity.User;
import com.project.Repositories.ExpenseRepository;

@Service
public class ExpenseServiceImpl implements ExpenseService {

	@Autowired
	private ExpenseRepository expenseRepository;

    @Autowired
    public ExpenseServiceImpl(ExpenseRepository expenseRepository) {
        this.expenseRepository = expenseRepository;
    }

    
    @Override
    public Expense addExpense(Expense expense) {
        return expenseRepository.save(expense);
    }

    @Override
    public List<Expense> getAllExpenses() {
        return expenseRepository.findAll();
    }

    @Override
    public Expense getExpenseById(Long id) {
        return expenseRepository.findById(id).orElse(null);
    }

    @Override
    public void deleteExpense(Long id) {
        expenseRepository.deleteById(id);
    }

    @Override
    public List<Expense> getAllExpensesByUser(User user) {
        return expenseRepository.findByUser(user);
    }


    @Override
    public BigDecimal getTotalExpensesByUser(User user) {
        List<Expense> expenses = expenseRepository.findByUser(user);
        BigDecimal totalExpenses = BigDecimal.ZERO;
        for (Expense expense : expenses) {
            totalExpenses = totalExpenses.add(expense.getAmount());
        }
        return totalExpenses;
    }

    @Override
    public List<Expense> getAllExpensesByUserId(Long userId) {
        return expenseRepository.findByUserId(userId);
    }
    
    @Override
    public List<Expense> findByUserId(Long userId) {
        return expenseRepository.findByUserId(userId);
    }

}
