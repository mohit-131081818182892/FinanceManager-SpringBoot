package com.project.Services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.Entity.BudgetManagement;
import com.project.Entity.Expense;
import com.project.Entity.FinanceReports;
import com.project.Entity.Income;
import com.project.Entity.User;
import com.project.Repositories.FinanceReportsRepository;
import jakarta.transaction.Transactional;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import org.thymeleaf.context.Context;
import org.xhtmlrenderer.pdf.ITextRenderer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.thymeleaf.TemplateEngine;
import com.lowagie.text.DocumentException;

@Service
@Transactional
public class FinanceReportServiceImpl implements FinanceReportsService {

	@Autowired
    private FinanceReportsRepository financeReportRepository;

	@Autowired
	private UserService userService;
	
	@Autowired
    private TemplateEngine templateEngine;

    @Value("classpath:templates/FinanceReports.html")
    private org.springframework.core.io.Resource financeReportsTemplate;

	
    @Override
    public List<FinanceReports> getReportsByUserId(Long userId) {
        return financeReportRepository.findByUserId(userId);
    }

    @Override
    public List<FinanceReports> getReportsByTypeAndDateRange(String type, LocalDate startDate, LocalDate endDate) {
        return financeReportRepository.findByTypeAndStartDateBetween(type, startDate, endDate);
    }

    @Override
    public List<FinanceReports> getReportsByUserIdAndType(Long userId, String type) {
        return financeReportRepository.findByUserIdAndType(userId, type);
    }

    @Override
    public List<FinanceReports> getReportsByUserIdAndEndDateAfter(Long userId, LocalDate endDate) {
        return financeReportRepository.findByUserIdAndEndDateAfter(userId, endDate);
    }

	@Override
	public List<Income> getIncomesByUserId(Long userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Expense> getExpensesByUserId(Long userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<BudgetManagement> getBudgetsByUserId(Long userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
    public ByteArrayInputStream exportFinanceReportPdf(String templateName, Map<String, Object> data) {
        // Initialize PDF content stream
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        try {
            // Create Thymeleaf context and set variables
            Context context = new Context();
            context.setVariables(data);

            // Process HTML template with Thymeleaf
            String htmlContent = templateEngine.process(templateName, context);

            // Initialize PDF renderer
            ITextRenderer renderer = new ITextRenderer();
            renderer.setDocumentFromString(htmlContent);

            // Set base URL for resolving resources (e.g., images, CSS)
            renderer.getSharedContext().setBaseURL(financeReportsTemplate.getURI().toString());

            // Render PDF
            renderer.layout();
            renderer.createPDF(outputStream);

            // Close renderer
            renderer.finishPDF();

            // Return PDF content as ByteArrayInputStream
            return new ByteArrayInputStream(outputStream.toByteArray());
        } catch (IOException | DocumentException e) {
            e.printStackTrace();
            return null;
        } finally {
            // Close output stream
            try {
                outputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    
}

