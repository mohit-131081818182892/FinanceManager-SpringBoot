package com.project.Services;

import java.util.List;

import com.project.Entity.Admin;
import com.project.Entity.User;

public interface AdminService {
	
	public Admin createAdmin(Admin admin, String url);
	
	public boolean checkEmail(String email);
		
	public boolean adminverifyAccount(String code);

	public Admin getAdminByUsername(String email);

	public void saveAdmin(Admin admin);

	public List<User> getAllUsers();

	public User getUserById(Long id);

	public void saveUser(User existingUser);
}
