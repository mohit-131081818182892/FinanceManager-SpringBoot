package com.project.Services;

import java.math.BigDecimal;
import java.util.List;
import com.project.Entity.Income;
import com.project.Entity.User;

public interface IncomeService {

	public Income addIncome(Income income);
	
    public List<Income> getAllIncomes();
    
    public Income getIncomeById(Long id);
    
    public void deleteIncome(Long id);

	public List<Income> getAllIncomesByUser(User user);

	public BigDecimal getTotalIncomeByUser(User user);

	public List<Income> getAllIncomesByUserId(Long id);

	public List<Income> findByUserId(Long userId);
}
