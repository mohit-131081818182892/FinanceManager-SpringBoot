package com.project.Services;

import java.math.BigDecimal;
import java.util.List;

import com.project.Entity.BudgetManagement;
import com.project.Entity.Expense;
import com.project.Entity.User;

public interface ExpenseService {

    public Expense addExpense(Expense expense);
    
    public List<Expense> getAllExpenses();
    
    public Expense getExpenseById(Long id);
    
    public void deleteExpense(Long id);

    public List<Expense> getAllExpensesByUser(User user);

	public BigDecimal getTotalExpensesByUser(User user);

	public List<Expense> getAllExpensesByUserId(Long userId);

	public List<Expense> findByUserId(Long userId);

}
