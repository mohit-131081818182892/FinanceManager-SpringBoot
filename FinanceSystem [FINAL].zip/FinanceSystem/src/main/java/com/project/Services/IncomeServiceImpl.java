package com.project.Services;

import java.math.BigDecimal;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.project.Entity.Income;
import com.project.Entity.User;
import com.project.Repositories.IncomeRepository;

@Service
public class IncomeServiceImpl implements IncomeService 
{

	 @Autowired
	 private IncomeRepository incomeRepository;

	 @Override
	 public Income addIncome(Income income) 
	 {
		 return incomeRepository.save(income);
	 }

	 @Override
	 public List<Income> getAllIncomes() 
	 {
		 return incomeRepository.findAll();
	 }

	 @Override
	 public Income getIncomeById(Long id) 
	 {
		 return incomeRepository.findById(id).orElse(null);
	 }

	 @Override
	 public void deleteIncome(Long id) 
	 {
		 incomeRepository.deleteById(id);
	 }

	@Override
	public List<Income> getAllIncomesByUser(User user) 
	{
		return incomeRepository.findByUser(user);
	}

	@Override
    public BigDecimal getTotalIncomeByUser(User user) {
        List<Income> incomes = incomeRepository.findByUser(user);
        BigDecimal totalIncome = BigDecimal.ZERO;
        for (Income income : incomes) {
            totalIncome = totalIncome.add(income.getAmount());
        }
        return totalIncome;
    }

	@Override
    public List<Income> getAllIncomesByUserId(Long userId) {
        return incomeRepository.findByUserId(userId);
    }
	
	@Override
    public List<Income> findByUserId(Long userId) {
        return incomeRepository.findByUserId(userId);
    }

}
