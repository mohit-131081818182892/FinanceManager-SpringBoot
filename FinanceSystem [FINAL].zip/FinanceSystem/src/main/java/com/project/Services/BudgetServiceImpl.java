package com.project.Services;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.project.Entity.BudgetManagement;
import com.project.Entity.User;
import com.project.Repositories.BudgetManagementRepository;
import com.project.Repositories.ExpenseRepository;
import com.project.Repositories.IncomeRepository;

@Service
public class BudgetServiceImpl implements BudgetService {

	private final BudgetManagementRepository budgetRepository;
    private final IncomeRepository incomeRepository;
    private final ExpenseRepository expenseRepository;

    public BudgetServiceImpl(BudgetManagementRepository budgetRepository,
                             IncomeRepository incomeRepository,
                             ExpenseRepository expenseRepository) {
        this.budgetRepository = budgetRepository;
        this.incomeRepository = incomeRepository;
        this.expenseRepository = expenseRepository;
    }

    @Override
    public List<BudgetManagement> getAllBudgets() {
        return budgetRepository.findAll();
    }

    @Override
    public List<BudgetManagement> getBudgetsByUser(User user) {
        return budgetRepository.findByUser(user);
    }

    @Override
    public Optional<BudgetManagement> getBudgetById(Long id) {
        return budgetRepository.findById(id);
    }

    @Override
    public BudgetManagement saveBudget(BudgetManagement budget) {
        return budgetRepository.save(budget);
    }

    @Override
    public void deleteBudget(Long id) {
        budgetRepository.deleteById(id);
    }

    @Override
    public BigDecimal getTotalBudgetLimit() {
        return budgetRepository.getTotalBudgetLimit();
    }

    @Override
    public BudgetManagement createBudget(BudgetManagement budget) {
        return budgetRepository.save(budget);
    }

    @Override
    public BudgetManagement updateBudget(Long id, BudgetManagement budget) {
        if (!budgetRepository.existsById(id)) {
            throw new IllegalArgumentException("Budget with ID " + id + " not found");
        }
        budget.setId(id);
        return budgetRepository.save(budget);
    }
    
    @Override
    public BigDecimal getRemainingBudget(User user) {
        BigDecimal totalIncome = incomeRepository.getTotalIncome(user);
        BigDecimal totalExpenses = expenseRepository.getTotalExpenses(user);
        return totalIncome.subtract(totalExpenses);
    }

    @Override
    public BigDecimal getSpentBudget(User user) {
        BigDecimal totalExpenses = expenseRepository.getTotalExpenses(user);
        return totalExpenses;
    }
    
    @Override
    public List<BudgetManagement> getAllBudgetsByUserId(Long userId) {
        return budgetRepository.findByUserId(userId);
    }
    
    @Override
    public List<BudgetManagement> findByUserId(Long userId) {
        return budgetRepository.findByUserId(userId);
    }
}
