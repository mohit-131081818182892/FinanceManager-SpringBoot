package com.project.Services;

import java.util.List;

import com.project.Entity.User;

public interface UserService {
	
	public User createUser(User user, String url);
	
	public boolean checkEmail(String email);
		
	public boolean verifyAccount(String code);

	public User getUserByUsername(String email);

	public void saveUser(User user);

	public User getUserById(Long userId);

	public User getCurrentUser();

	public User findById(Long userId);
	
	public List<User> getAllUsers();

	public long getTotalUsers();

	public void deleteUser(Long id);
}
