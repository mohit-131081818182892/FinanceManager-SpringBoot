package com.project.Services;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import com.project.Entity.User;
import com.project.Repositories.UserRepository;
import jakarta.mail.internet.MimeMessage;

@Service
public class UserServiceImpl implements UserService{
	
	@Autowired
	private UserRepository userRepo;
	
	@Autowired
	private BCryptPasswordEncoder passwordEncode;
	
	@Autowired
	private JavaMailSender mailSender;
	
	@Override
	public User createUser(User user, String url) {
		
		user.setPassword(passwordEncode.encode(user.getPassword()));
		user.setRole("ROLE_USER");
		
		user.setEnabled(false); 
		
		user.setVerificationCode(UUID.randomUUID().toString());
		
		User us = userRepo.save(user);
		
		if(us!=null)
		{
			sendVerificationMail(user, url);
		}
		return us;
	}

	@Override
	public boolean checkEmail(String email) { 
		
		return userRepo.existsByEmail(email);
	}
	
	
	public void sendVerificationMail(User user, String url)
	{
		String from ="pranaysureshalame@gmail.com";
		String to = user.getEmail();
		String subject = "Account Verification";
		String content = "Dear [[name]],<br>"
				+ "Please click the link below to verify your registration:<br>"
				+ "<h3><a href=\"[[URL]]\" target=\"_self\">VERIFY</a></h3>"
				+ "Thank you,<br>"
				+ "Your company name.";
		try {
			
			MimeMessage message = mailSender.createMimeMessage();
			MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");
			
			helper.setFrom(from,"Admin");
			helper.setTo(to);
			helper.setSubject(subject);
			
			content = content.replace("[[name]]", user.getFirstName());
			
			String siteUrl =url+"/verify?code="+user.getVerificationCode();
			
			content = content.replace("[[URL]]", siteUrl);
			
			helper.setText(content, true);
			
			mailSender.send(message);
			
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	
	@Override
	public boolean verifyAccount(String code) {
		
		User user = userRepo.findByVerificationCode(code);
		
		if(user!=null)
		{
			user.setAccountNonLocked(true);
			user.setEnabled(true);
			user.setVerificationCode(null);
			userRepo.save(user);
			return true;
		}
		
		return false;
	}
	
	@Override
    public User getUserByUsername(String username) {
        return userRepo.findByUsername(username);
    }

	@Override
    public void saveUser(User user) {
        userRepo.save(user);
    }

	@Override
    public User getUserById(Long userId) {
        return userRepo.findById(userId).orElse(null);
    }

	@Override
    public User getCurrentUser() {
        // Retrieve the authentication object from the SecurityContextHolder
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        // Check if the authentication object is not null and contains the principal (user details)
        if (authentication != null && authentication.getPrincipal() instanceof UserDetails) {
            UserDetails userDetails = (UserDetails) authentication.getPrincipal();
            
            // Assuming your user entity has a field for username, you can retrieve the user by username
            return userRepo.findByUsername(userDetails.getUsername());
        }
        
        return null; // Return null if no authenticated user is found
    }
	
	@Override
    public User findById(Long userId) {
        return userRepo.findById(userId).orElse(null);
    }


	@Override
    public List<User> getAllUsers() {
        return userRepo.findAll();
    }

	@Override
	public long getTotalUsers() {
		return userRepo.count();
    }

	public void deleteUser(Long userId) {
        userRepo.deleteById(userId);
    }

	
}
