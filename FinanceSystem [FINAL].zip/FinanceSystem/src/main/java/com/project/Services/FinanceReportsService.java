package com.project.Services;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.io.ByteArrayInputStream;

import com.project.Entity.BudgetManagement;
import com.project.Entity.Expense;
import com.project.Entity.FinanceReports;
import com.project.Entity.Income;

public interface FinanceReportsService {
    
    public List<FinanceReports> getReportsByUserId(Long userId);
    
    public List<FinanceReports> getReportsByTypeAndDateRange(String type, LocalDate startDate, LocalDate endDate);
    
    public List<FinanceReports> getReportsByUserIdAndType(Long userId, String type);
    
    public List<FinanceReports> getReportsByUserIdAndEndDateAfter(Long userId, LocalDate endDate);
    
    public List<Income> getIncomesByUserId(Long userId);
    
    public List<Expense> getExpensesByUserId(Long userId);
    
    public List<BudgetManagement> getBudgetsByUserId(Long userId);
   
    public ByteArrayInputStream exportFinanceReportPdf(String templateName, Map<String, Object> data);
    
    // You can add more methods as per your requirements
    
}
