package com.project.Services;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import com.project.Entity.BudgetManagement;
import com.project.Entity.User;

public interface BudgetService {

	public List<BudgetManagement> getAllBudgets();

    public List<BudgetManagement> getBudgetsByUser(User user);

    public Optional<BudgetManagement> getBudgetById(Long id);

    public BudgetManagement saveBudget(BudgetManagement budget);

    public void deleteBudget(Long id);

    public BigDecimal getTotalBudgetLimit();
    
    public BudgetManagement createBudget(BudgetManagement budget);
    
    public BudgetManagement updateBudget(Long id, BudgetManagement budget);

	BigDecimal getRemainingBudget(User user);

	BigDecimal getSpentBudget(User user);

	public List<BudgetManagement> getAllBudgetsByUserId(Long userId);

	public List<BudgetManagement> findByUserId(Long userId);
}
