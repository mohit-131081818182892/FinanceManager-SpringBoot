package com.project.Controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.project.Entity.SecuritySettings;
import com.project.Entity.User;
import com.project.Services.AdminService;
import com.project.Services.UserService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/admin")
public class AdminController {

	@Autowired
    private AdminService adminService;
	
	@Autowired
	private UserService userService;
	
	
	
	
	@GetMapping("/")
	public String home()
	{
		return "admin/home";
	}
	
	@GetMapping("/home")
	public String dashboard()
	{
		return "admin/home";
	}
	
	@GetMapping("/createUser")
	public String createUserPage()
	{
	    return "admin/createUser";
	}
	
	@GetMapping("/updateUser")
	public String editUserPage()
	{
	    return "admin/editUser";
	}
	
	@GetMapping("/dataManage")
	public String dataManagePage()
	{
	    return "admin/dataManagement";
	}
	
	@GetMapping("/systemConfig")
	public String systemConfigPage(Model model)
	{
		model.addAttribute("security", securitySettings);
	    return "admin/systemConfiguration";
	}
	
	// USER MANAGEMENT :-
	
	@GetMapping("/userManage")
	public String userManagement(Model model) {
	    List<User> users = adminService.getAllUsers(); // Assuming this method returns a list of users
	    model.addAttribute("users", users);
	    return "userManagement"; // Assuming the HTML file is named userManagement.html
	}

	
	@PostMapping("/createUser")
	public String createUser(@ModelAttribute User user, HttpSession session, HttpServletRequest request) {
	    String url = request.getRequestURL().toString();
	    url = url.replace(request.getServletPath(), "");

	    boolean emailExists = userService.checkEmail(user.getEmail());
	    if (emailExists) {
	        session.setAttribute("msg", "Email ID already exists!");
	    } else {
	        User createdUser = userService.createUser(user, url);
	        if (createdUser != null) {
	            session.setAttribute("msg", "User registered successfully!");
	        } else {
	            session.setAttribute("msg", "User registration failed!");
	        }
	    }
	    session.removeAttribute("msg");
	    return "redirect:/admin/userManage";
	}

	
	  @GetMapping("/verify")
	    public String verifyAccount(@Param("code") String code)
	    {
	    	boolean f = userService.verifyAccount(code);
	    	if(f)
	    	{
	    		return "verify_Success";
	    	}else {
	    		return "verify_Failed";
	    	}
	    	
	    }

	  @GetMapping("/totalUsers") 
	  @ResponseBody // Ensure the response is sent as JSON
	  public long getTotalUsers() {
	      return userService.getTotalUsers();
	  }
	  
	  //for fetching the details of user in the form
	  @GetMapping("/getUser")
	  @ResponseBody
	  public ResponseEntity<User> getUser(@RequestParam Long id) {
	      User user = adminService.getUserById(id);
	      if(user != null) {
	          return ResponseEntity.ok(user);
	      } else {
	          return ResponseEntity.notFound().build();
	      }
	  }
	  
	  @DeleteMapping("/deleteUser/{userId}")
	    public ResponseEntity<?> deleteUser(@PathVariable Long userId) {
	        userService.deleteUser(userId);
	        return ResponseEntity.ok().build();
	    }
	  
	  private SecuritySettings securitySettings = new SecuritySettings("Enabled", "Strong", "Enabled");
	  
	  @GetMapping("/security")
	    public String showSecuritySettings(Model model) {
	        model.addAttribute("security", securitySettings);
	        return "systemConfiguration";
	    }

	    @PostMapping("/saveSecuritySettings")
	    public String saveSecuritySettings(SecuritySettings security) {
	        securitySettings.setAccessControls(security.getAccessControls());
	        securitySettings.setPasswordPolicy(security.getPasswordPolicy());
	        securitySettings.setActivityMonitoring(security.getActivityMonitoring());
	        return "redirect:/security";
	    }

	  
}// securityConfiguration work is remain , user edit and delete work is remain.
