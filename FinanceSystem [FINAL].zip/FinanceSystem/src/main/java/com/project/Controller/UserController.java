package com.project.Controller;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.security.Principal;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.project.Entity.BudgetManagement;
import com.project.Entity.Expense;
import com.project.Entity.FinanceReports;
import com.project.Entity.Income;
import com.project.Entity.User;
import com.project.Repositories.IncomeRepository;
import com.project.Repositories.UserRepository;
import com.project.Services.BudgetService;
import com.project.Services.ExpenseService;
import com.project.Services.FinanceReportsService;
import com.project.Services.IncomeService;
import com.project.Services.UserService;
import jakarta.servlet.http.HttpSession;


@Controller
@RequestMapping("/user")
public class UserController {
	
	@Autowired
	private UserRepository userRepo;
	
	@Autowired
	private BCryptPasswordEncoder passwordEncode;
	
	@Autowired
    private IncomeRepository incomeRepo;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private IncomeService incomeService;
	
	@Autowired
	private ExpenseService expenseService;
	
	@Autowired
	private BudgetService budgetService;
	
	@Autowired
    private FinanceReportsService financeReportService;
	
	@ModelAttribute
	private void userDetails(Model m, Principal p)
	{
		String email = p.getName();
		User user =userRepo.findByUsername(email);
		
		m.addAttribute("user",user);
	}
	
	@GetMapping("/")
	public String home()
	{
		return "user/Home";
	}
	
	@GetMapping("/editPassword")
	public String editPassword()
	{
		return "user/Change_Password";
	}
	
	@GetMapping("/incomedash")
    public String incomeDashPage() {
        return "income"; 
    }
	
	// Inside UserController.java

	@GetMapping("/income")
	public String incomePage(Model model, Principal principal) {
	    try {
	        String email = principal.getName();
	        User user = userService.getUserByUsername(email);
	        if (user == null) {
	            return "error";
	        }

	        // Fetch all incomes for the user
	        List<Income> incomes = incomeService.getAllIncomesByUser(user);

	        // Calculate existing statistics
	        BigDecimal totalIncome = BigDecimal.ZERO;
	        BigDecimal highestIncome = BigDecimal.ZERO;
	        BigDecimal lowestIncome = BigDecimal.ZERO;
	        BigDecimal monthlyAverage = BigDecimal.ZERO;

	        if (!incomes.isEmpty()) {
	            for (Income income : incomes) {
	                totalIncome = totalIncome.add(income.getAmount());
	                highestIncome = highestIncome.max(income.getAmount());
	                lowestIncome = (lowestIncome.equals(BigDecimal.ZERO)) ? income.getAmount() : lowestIncome.min(income.getAmount());
	            }
	            monthlyAverage = totalIncome.divide(BigDecimal.valueOf(incomes.size()), 2, RoundingMode.HALF_UP);
	        }

	        // Calculate additional statistics
	        BigDecimal totalExpenses = BigDecimal.ZERO;
	        BigDecimal averagePerIncome = BigDecimal.ZERO;

	        // Calculate average income per entry
	        if (!incomes.isEmpty()) {
	            averagePerIncome = totalIncome.divide(BigDecimal.valueOf(incomes.size()), 2, RoundingMode.HALF_UP);
	        }

	        // Pass all statistics to the frontend
	        model.addAttribute("totalIncome", totalIncome);
	        model.addAttribute("monthlyAverage", monthlyAverage);
	        model.addAttribute("highestIncome", highestIncome);
	        model.addAttribute("lowestIncome", lowestIncome);
	        model.addAttribute("averagePerIncome", averagePerIncome);
	        model.addAttribute("incomes", incomes);

	        return "income";
	    } catch (Exception e) {
	        e.printStackTrace();
	        return "error";
	    }
	}

	@GetMapping("/changePass")
	public String loadchangPassword()
	{
		return "user/Change_Password";
	}
	
	@GetMapping("/changePassword")
	public String changPassword()
	{
		return "user/Change_Password";
	}
	
	@PostMapping("/updatePass")
	public String ChangePassword(Principal p,@RequestParam("oldPass") String oldPass,
			@RequestParam("newPass") String newPass, HttpSession session)
	{
		String email = p.getName();
		User loginuser = userRepo.findByUsername(email);
		
		boolean f = passwordEncode.matches(oldPass, loginuser.getPassword());
		if(f)
		{
			loginuser.setPassword(passwordEncode.encode(newPass));
			User updatePass = userRepo.save(loginuser);
			if(updatePass!=null)
			{
				session.setAttribute("Msg", "Password Successfully Update!");
			}else {
				session.setAttribute("Msg", "Password Not Update!");
			}
		}else {
			session.setAttribute("Msg", "Old Password Incorrect!");
		}
		
		session.removeAttribute("msg");
		return "redirect:/user/changePass";
	}
	
	@GetMapping("/editIncome")
    public String editIncomePage() {
        return "user/editIncome"; 
    }
	
	
	
	@PostMapping("/addIncome")
	public String addIncome(@ModelAttribute("income") Income income, Principal principal) {
	    String email = principal.getName();
	    User user = userRepo.findByUsername(email);
	    income.setUser(user);
	    user.getIncomes().add(income);
	    userRepo.save(user);
	    
	    return "redirect:/user/income";
	}
	
	@GetMapping("/income/{incomeId}")
	public String getIncome(Model model, Principal principal, @PathVariable Long incomeId) {
	    String username = principal.getName();
	    User user = userRepo.findByUsername(username);
	    if (user == null) {
	        return "error"; 
	    }

	    Income income = incomeRepo.findById(incomeId).orElse(null);
	    if (income == null || !income.getUser().getId().equals(user.getId())) {
	        return "error"; 
	    }

	    model.addAttribute("income", income);
	    return "incomeDetails"; 
	}

	
	@GetMapping("/editIncome/{id}")
	public String editIncomeForm(@PathVariable("id") Long id, Model model) {
	    Income income = incomeRepo.findById(id).orElse(null);
	    if (income != null) {
	        model.addAttribute("income", income);
	        return "editIncome"; // Assuming you have an HTML template for editing income details
	    } else {
	        return "redirect:/user/income"; // Redirect to income page if income not found
	    }
	}

	@PostMapping("/updateIncome")
	public String updateIncome(@ModelAttribute("income") Income updatedIncome, User user) {
		Income existingIncome = incomeRepo.findById(updatedIncome.getId()).orElse(null);
	    if (existingIncome != null) {
	        existingIncome.setAmount(updatedIncome.getAmount());
	        existingIncome.setCategory(updatedIncome.getCategory());
	        existingIncome.setDate(updatedIncome.getDate());
	        existingIncome.setDescription(updatedIncome.getDescription());
	        incomeRepo.save(existingIncome);
            
	    }
	    return "redirect:/user/income"; // Redirect to income page after updating
	}

	@GetMapping("/cancelEdit")
	public String cancelEdit() {
	    // Redirect to the income page without making any changes
	    return "redirect:/user/income";
	}
	
	@GetMapping("/incomeManage")
	public String incomeManage() {
	    // Redirect to the income page without making any changes
	    return "redirect:/user/income";
	}
	
	@PostMapping("/deleteIncome/{id}")
	public String deleteIncome(@PathVariable("id") Long id, Principal principal) {
	    try {
	        String username = principal.getName();
	        User user = userService.getUserByUsername(username);
	        if (user == null) {
	            return "error"; // Handle error gracefully
	        }

	        Income income = incomeService.getIncomeById(id);
	        if (income == null || !income.getUser().getId().equals(user.getId())) {
	            return "error"; // Handle error gracefully
	        }

	        incomeService.deleteIncome(id);
	        return "redirect:/user/income"; // Redirect to income page after deleting
	    } catch (Exception e) {
	        e.printStackTrace();
	        return "error"; // Handle error gracefully
	    }
	}

	
	//Expense
	@GetMapping("/expense")
	public String expensePage(Model model, Principal principal) {
	    try {
	        String email = principal.getName();
	        User user = userService.getUserByUsername(email);
	        if (user == null) {
	            return "error";
	        }

	        // Fetch all expenses for the user
	        List<Expense> expenses = expenseService.getAllExpensesByUser(user);

	        // Calculate existing statistics
	        BigDecimal totalExpense = BigDecimal.ZERO;
	        BigDecimal highestExpense = BigDecimal.ZERO;
	        BigDecimal lowestExpense = BigDecimal.ZERO;
	        BigDecimal monthlyAverage = BigDecimal.ZERO;
	        BigDecimal averagePerExpense = BigDecimal.ZERO;
	        
	        if (!expenses.isEmpty()) {
	            for (Expense expense : expenses) {
	                totalExpense = totalExpense.add(expense.getAmount());
	                highestExpense = highestExpense.max(expense.getAmount());
	                lowestExpense = (lowestExpense.equals(BigDecimal.ZERO)) ? expense.getAmount() : lowestExpense.min(expense.getAmount());
	            }
	            monthlyAverage = totalExpense.divide(BigDecimal.valueOf(expenses.size()), 2, RoundingMode.HALF_UP);
	        }
	        
	     // Calculate average income per entry
	        if (!expenses.isEmpty()) {
	            averagePerExpense = totalExpense.divide(BigDecimal.valueOf(expenses.size()), 2, RoundingMode.HALF_UP);
	        }

	        
	        // Pass all statistics to the frontend
	        model.addAttribute("totalExpense", totalExpense);
	        model.addAttribute("monthlyAverage", monthlyAverage);
	        model.addAttribute("highestExpense", highestExpense);
	        model.addAttribute("lowestExpense", lowestExpense);
	        model.addAttribute("averagePerExpense", averagePerExpense);
	        model.addAttribute("expenses", expenses);
	        
	        return "expense";
	    } catch (Exception e) {
	        e.printStackTrace();
	        return "error";
	    }
	}


    @PostMapping("/addExpense")
    public String addExpense(@ModelAttribute("expense") Expense expense, Principal principal) {
        String email = principal.getName();
        User user = userService.getUserByUsername(email);
        expense.setUser(user);
        user.getExpenses().add(expense);
        userService.saveUser(user);
        
        return "redirect:/user/expense";
    }

 // Inside UserController.java

    @GetMapping("/editExpense/{id}")
    public String editExpenseForm(@PathVariable("id") Long id, Model model) {
        Expense expense = expenseService.getExpenseById(id);
        if (expense != null) {
            model.addAttribute("expense", expense);
            return "editExpense"; 
        } else {
            return "redirect:/user/expense"; 
        }
    }

    @PostMapping("/updateExpense")
    public String updateExpense(@ModelAttribute("expense") Expense updatedExpense, User user) {
        Expense existingExpense = expenseService.getExpenseById(updatedExpense.getId());
        if (existingExpense != null) {
            existingExpense.setAmount(updatedExpense.getAmount());
            existingExpense.setCategory(updatedExpense.getCategory());
            existingExpense.setDate(updatedExpense.getDate());
            existingExpense.setDescription(updatedExpense.getDescription());
            expenseService.addExpense(existingExpense);
            

        }
        return "redirect:/user/expense"; 
    }

    @GetMapping("/cancelEditExpense")
    public String cancelEditExpense() {
        
        return "redirect:/user/expense";
    }
    
    @GetMapping("/expenseManage")
	public String expenseManage() {
	    // Redirect to the income page without making any changes
	    return "redirect:/user/expense";
	}

    @PostMapping("/deleteExpense/{id}")
    public String deleteExpense(@PathVariable("id") Long id, Principal principal) {
        try {
            String email = principal.getName();
            User user = userService.getUserByUsername(email);
            if (user == null) {
                return "error"; // Handle error gracefully
            }

            Expense expense = expenseService.getExpenseById(id);
            if (expense == null || !expense.getUser().getId().equals(user.getId())) {
                return "error"; // Handle error gracefully
            }

            expenseService.deleteExpense(id);
            return "redirect:/user/expense"; // Redirect to expense page after deleting
        } catch (Exception e) {
            e.printStackTrace();
            return "error"; // Handle error gracefully
        }
    }

    
    //BUDGET MANAGEMENT
    
    @GetMapping("/budget")
    public String budgetPage(Model model, Principal principal) {
        try {
            String email = principal.getName();
            User user = userService.getUserByUsername(email);
            if (user == null) {
                return "error";
            }

            // Fetch all budgets for the user
            List<BudgetManagement> budgets = budgetService.getBudgetsByUser(user);

            // Calculate total income and expenses
            BigDecimal totalIncome = incomeService.getTotalIncomeByUser(user);
            BigDecimal totalExpenses = expenseService.getTotalExpensesByUser(user);

            // Calculate total budget
            BigDecimal totalBudget = BigDecimal.ZERO;
            for (BudgetManagement budget : budgets) {
                totalBudget = totalBudget.add(budget.getLimitAmount());
            }

            // Calculate spent budget
            BigDecimal spentBudget = totalExpenses;

            // Calculate remaining budget
            BigDecimal remainingBudget = totalBudget.subtract(spentBudget);

            // Pass all statistics to the frontend
            model.addAttribute("totalBudget", totalBudget);
            model.addAttribute("spentBudget", spentBudget);
            model.addAttribute("remainingBudget", remainingBudget);
            model.addAttribute("budgets", budgets);

            return "budgetManagement";
        } catch (Exception e) {
            e.printStackTrace();
            return "error";
        }
    }


    @PostMapping("/addBudget")
    public String addBudget(@ModelAttribute("budget") BudgetManagement budget, Principal principal) {
        String email = principal.getName();
        User user = userService.getUserByUsername(email);
        budget.setUser(user);
        budgetService.saveBudget(budget);
        
        return "redirect:/user/budget";
    }

    @GetMapping("/editBudget/{id}")
    public String editBudgetForm(@PathVariable("id") Long id, Model model) {
        BudgetManagement budget = budgetService.getBudgetById(id).orElse(null);
        if (budget != null) {
            model.addAttribute("budget", budget);
            return "editBudgetManagement"; 
        } else {
            return "redirect:/user/budget"; 
        }
    }

    @PostMapping("/updateBudget")
    public String updateBudget(@ModelAttribute("budget") BudgetManagement updatedBudget, User user) {
        BudgetManagement existingBudget = budgetService.getBudgetById(updatedBudget.getId()).orElse(null);
        if (existingBudget != null) {
            existingBudget.setCategoryName(updatedBudget.getCategoryName());
            existingBudget.setLimitAmount(updatedBudget.getLimitAmount());
            budgetService.saveBudget(existingBudget);
            
        }
        return "redirect:/user/budget"; 
    }

    @GetMapping("/cancelEditBudget")
    public String cancelEditBudget() {
        return "redirect:/user/budget";
    }

    @PostMapping("/deleteBudget/{id}")
    public String deleteBudget(@PathVariable("id") Long id) {
        budgetService.deleteBudget(id);
        return "redirect:/user/budget"; 
    }
    
    @GetMapping("/budgetManage")
	public String budgetManage() {
	    // Redirect to the income page without making any changes
	    return "redirect:/user/budget";
	}

    
    // Display the Values in Dashboard for looking like a realtime:

    @GetMapping("/dashboard")
    public String dashboard(Model model, Principal principal) {
        try {
            String email = principal.getName();
            User user = userService.getUserByUsername(email);
            if (user == null) {
                return "error";
            }

            // Calculate total income
            BigDecimal totalIncome = incomeService.getTotalIncomeByUser(user);

            // Calculate total expenses
            BigDecimal totalExpenses = expenseService.getTotalExpensesByUser(user);

            // Calculate savings
            BigDecimal savings = totalIncome.subtract(totalExpenses);

            // Fetch all budgets for the user
            List<BudgetManagement> budgets = budgetService.getBudgetsByUser(user);

            // Calculate total budget
            BigDecimal totalBudget = BigDecimal.ZERO;
            for (BudgetManagement budget : budgets) {
                totalBudget = totalBudget.add(budget.getLimitAmount());
            }

            // Calculate budget utilization percentage
            BigDecimal budgetUtilizationPercentage = BigDecimal.ZERO;
            if (totalBudget.compareTo(BigDecimal.ZERO) > 0) {
                budgetUtilizationPercentage = totalExpenses.divide(totalBudget, 2, RoundingMode.HALF_UP).multiply(BigDecimal.valueOf(100));
            }

            // Pass all calculated metrics to the frontend
            model.addAttribute("totalIncome", totalIncome);
            model.addAttribute("totalExpenses", totalExpenses);
            model.addAttribute("savings", savings);
            model.addAttribute("budgetUtilizationPercentage", budgetUtilizationPercentage);

            return "user/home"; 
        } catch (Exception e) {
            e.printStackTrace();
            return "error";
        }
    }
    
    //FinanceReports
    
    @GetMapping("/finance-reports")
    public String financeReportsPage(Model model) {
        // Retrieve user details
        User user = userService.getCurrentUser();

        // Retrieve finance-related data
        List<Income> incomes = incomeService.getAllIncomesByUserId(user.getId());
        List<Expense> expenses = expenseService.getAllExpensesByUserId(user.getId());
        List<BudgetManagement> budgets = budgetService.getAllBudgetsByUserId(user.getId());

        // Add data to the model
        model.addAttribute("user", user);
        model.addAttribute("incomes", incomes);
        model.addAttribute("expenses", expenses);
        model.addAttribute("budgets", budgets);

        return "financeReports"; // Thymeleaf template name
    }
    
    @GetMapping("/user/{userId}/reports")
    public List<FinanceReports> getUserReports(@PathVariable Long userId) {
        return financeReportService.getReportsByUserId(userId);
    }
    /*
    @GetMapping("/download-pdf")
    @ResponseBody
    public void downloadFinanceReportPdf(@RequestParam("userId") Long userId, HttpServletResponse response) throws IOException, DocumentException {
        // Set response headers
        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "attachment; filename=ReportReceipt.pdf");

        // Create PDF document
        Document document = new Document(PageSize.A4);
        PdfWriter.getInstance(document, response.getOutputStream());

        document.open();

        // Get user details
        User user = userService.findById(userId); // Assuming you have a method to find user by ID in UserService

        // Add title
        Font titleFont = new Font(Font.HELVETICA, 18, Font.BOLD);
        Paragraph title = new Paragraph("Finance Report", titleFont);
        title.setAlignment(Paragraph.ALIGN_CENTER);
        document.add(title);

        // Add user details
        document.add(new Paragraph("User Details:"));
        document.add(new Paragraph("First Name: " + user.getFirstName()));
        document.add(new Paragraph("Last Name: " + user.getLastName()));
        document.add(new Paragraph("Email: " + user.getEmail()));
        document.add(new Paragraph("Mobile Number: " + user.getMobileNumber()));

        // Add income details
        document.add(new Paragraph("Income Details:"));
        PdfPTable incomeTable = new PdfPTable(4);
        incomeTable.addCell("ID");
        incomeTable.addCell("Amount");
        incomeTable.addCell("Date");
        incomeTable.addCell("Description");
        List<Income> incomes = incomeService.getAllIncomesByUser(user);
        for (Income income : incomes) {
            incomeTable.addCell(String.valueOf(income.getId()));
            incomeTable.addCell(String.valueOf(income.getAmount()));
            incomeTable.addCell(income.getDate().toString());
            incomeTable.addCell(income.getDescription());
        }
        document.add(incomeTable);

        // Add expense details
        document.add(new Paragraph("Expense Details:"));
        PdfPTable expenseTable = new PdfPTable(4);
        expenseTable.addCell("ID");
        expenseTable.addCell("Amount");
        expenseTable.addCell("Date");
        expenseTable.addCell("Description");
        List<Expense> expenses = expenseService.getAllExpensesByUser(user);
        for (Expense expense : expenses) {
            expenseTable.addCell(String.valueOf(expense.getId()));
            expenseTable.addCell(String.valueOf(expense.getAmount()));
            expenseTable.addCell(expense.getDate().toString());
            expenseTable.addCell(expense.getDescription());
        }
        document.add(expenseTable);

        // Add budget details
        document.add(new Paragraph("Budget Details:"));
        PdfPTable budgetTable = new PdfPTable(3); // Assuming budget has ID, Amount, and Category
        budgetTable.addCell("ID");
        budgetTable.addCell("Amount");
        budgetTable.addCell("Category");
        List<BudgetManagement> budgets = budgetService.getBudgetsByUser(user);
        for (BudgetManagement budget : budgets) {
            budgetTable.addCell(String.valueOf(budget.getId()));
            budgetTable.addCell(String.valueOf(budget.getLimitAmount()));
            budgetTable.addCell(budget.getCategoryName());
        }
        document.add(budgetTable);

        // Export PDF using Thymeleaf template
        Map<String, Object> data = new HashMap<>();
        // You can add more data to the map if required
        ByteArrayInputStream byteArrayInputStream = financeReportService.exportFinanceReportPdf("ReportReceipt", data);
        byte[] buffer = new byte[1024];
        int bytesRead;
        while ((bytesRead = byteArrayInputStream.read(buffer)) != -1) {
            response.getOutputStream().write(buffer, 0, bytesRead);
        }
        byteArrayInputStream.close();

        document.close();
    }
    */
    
    
    

    
} 





