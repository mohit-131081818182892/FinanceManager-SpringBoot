package com.project.Controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.project.Entity.Admin;
import com.project.Entity.User;
import com.project.Repositories.AdminRepository;
import com.project.Repositories.UserRepository;
import com.project.Services.AdminService;
import com.project.Services.UserService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;


@Controller
public class HomeController {
	
		@Autowired
		private UserService userservice;
		
		@Autowired
	    private AdminService adminService;

	    @Autowired
	    private AdminRepository adminRepo;
	
		@Autowired
		private UserRepository userRepo;
		
		@Autowired
		private BCryptPasswordEncoder passwordEncode;
		
		@ModelAttribute
		private void serDetails(Model m, Principal p)
		{
			if(p!=null)
			{
				String email = p.getName();
				User user =userRepo.findByUsername(email);
				m.addAttribute("user",user);
			}
		}
		
		
	 	@GetMapping("/index")
	    public String index() {
	        return "index"; 
	    }
	    
	 	// USER MAPPING:
	 	
	    @GetMapping("/signin")
	    public String login() {
	        return "login"; 
	    }
	    
	    @PostMapping("/login")
	    public String loginUser(@RequestParam String username, @RequestParam String password, HttpSession session) {
	        return "redirect:user/Home"; // Redirect to the index page
	    }

	    /*@GetMapping("/user/Home")
	    public String userHome() {
	        return "user/Home"; // Return the name of the view for user home page
	    }
	    */
	    @GetMapping("/register")
	    public String register() {
	        return "register"; 
	    }
	    
	    @PostMapping("/createUser")
	    public String creatuser(@ModelAttribute User user, HttpSession session,HttpServletRequest request)
	    {
	    	String url = request.getRequestURL().toString();
	    	
	    	url = url.replace(request.getServletPath(), "");
	    	
	    	boolean f = userservice.checkEmail(user.getEmail());
	    	
	    	if(f)
	    	{
	    		session.setAttribute("msg","Email id Already Exist");
	    	}
	    	else
	    	{
	    		User userdtls = userservice.createUser(user, url);
	    		if(userdtls!=null)
	    		{
	    			session.setAttribute("msg","Register Successfully!");
	    		}
	    		else
	    		{
	    			session.setAttribute("msg","Register Failed!!");
	    		}
	    	
	    	}
	    	//session.removeAttribute("msg");
	    	return "redirect:/register";
	    }
	    
	    @GetMapping("/verify")
	    public String verifyAccount(@Param("code") String code)
	    {
	    	boolean f = userservice.verifyAccount(code);
	    	if(f)
	    	{
	    		return "verify_Success";
	    	}else {
	    		return "verify_Failed";
	    	}
	    	
	    }
	    
	    @GetMapping("/loadForgotPassword")
	    public String loadForgotPass()
	    {
	    	return "Forgot_Password";
	    }
	    
	    @GetMapping("/loadResetPassword/{id}")
	    public String loadResetPass(@PathVariable int id, Model m)
	    {
	    	m.addAttribute("id", id);
	    	return "Reset_Password";
	    }
	    
	    @PostMapping("/forgotPassword")
	    public String forgotPassword(@RequestParam String email,
	    		@RequestParam String mobileNumber, HttpSession session)
	    {
	    	User user = userRepo.findByEmailAndMobileNumber(email, mobileNumber);
	    	
	    	if(user!=null)
	    	{
	    		return "redirect:/loadResetPassword/" + user.getId();
	    	}else {
	    		session.setAttribute("mesg", "Invalid Email & Mobile Number");
	    		session.removeAttribute("mesg");
	    		return "Forgot_Password";
	    	}
	    
	    }
	    
	    @PostMapping("/changePassword")
	    public String resetPassword(@RequestParam String password,
	    		@RequestParam Long id, HttpSession session)
	    {
	    	User user = userRepo.findById(id).orElse(null);
	    	
	    	if (user != null) 
	    	{
	    		// Set the new password and save the user
	            user.setPassword(passwordEncode.encode(password));
	            User updateUser = userRepo.save(user);
	            
	            /*String encryptPassword = passwordEncode.encode(password);
	            User updateUser = userRepo.save(user);
	             */
	    	
	            if(updateUser!=null)
	            {
	            	session.setAttribute("message", "Password Change Successfully!");
	            }
	            else
	            {
	            	session.setAttribute("message", "Failed to change password. Please try again.");
	            }
	    	}
	    	else 
	    	{
	            session.setAttribute("message", "User not found.");
	        }
	    	
	    	session.removeAttribute("message");
	    	return "redirect:/loadForgotPassword";
	    }
	    
	    // ADMIN 
	    
	    @ModelAttribute
	    private void setAdminDetails(Model model, Principal principal) {
	        if (principal != null) {
	            String email = principal.getName();
	            Admin admin = adminRepo.findByUsername(email);
	            model.addAttribute("admin", admin);
	        }
	    }

	    @GetMapping("/admin/index")
	    public String adminIndex() {
	        return "admin/index";
	    }

	    @GetMapping("/adminlogin")
	    public String adminLogin() {
	        return "adminLogin";
	    }

	    @GetMapping("/adminregister") // Mapping for adminRegister
	    public String adminRegisterPage() {
	        return "adminRegister";
	    }

	    @PostMapping("/createAdmin") // Mapping for adminRegister POST method
	    public String createAdmin(@ModelAttribute Admin admin, HttpSession session, HttpServletRequest request) {
	        String url = request.getRequestURL().toString();
	        url = url.replace(request.getServletPath(), "");

	        boolean exists = adminService.checkEmail(admin.getEmail());

	        if (exists) {
	            session.setAttribute("msg", "Email id Already Exist");
	        } else {
	            Admin adminDetails = adminService.createAdmin(admin, url);
	            if (adminDetails != null) {
	                session.setAttribute("msg", "Register Successfully!");
	            } else {
	                session.setAttribute("msg", "Register Failed!!");
	            }
	        }
	        session.removeAttribute("msg");
	        return "redirect:/admin/register";
	    }
	    
	    @GetMapping("/adminVerify")
	    public String verifyAdminAccount(@Param("code") String code) {
	        boolean isAdminVerified = adminService.adminverifyAccount(code);
	        if (isAdminVerified) {
	            return "adminVerify_Success";
	        } else {
	            return "adminVerify_Failed";
	        }
	    }


	    @GetMapping("/adminloadForgotPassword")
	    public String loadAdminForgotPass() {
	        return "adminForgot_Password";
	    }

	    @GetMapping("/adminloadResetPassword/{id}")
	    public String loadAdminResetPass(@PathVariable int id, Model model) {
	        model.addAttribute("id", id);
	        return "adminReset_Password";
	    }

	    @PostMapping("/adminforgotPassword")
	    public String adminForgotPassword(@RequestParam String email,
	                                      @RequestParam String mobileNumber, HttpSession session) {
	        Admin admin = adminRepo.findByEmailAndMobileNumber(email, mobileNumber);

	        if (admin != null) {
	            return "redirect:/admin/loadResetPassword/" + admin.getId();
	        } else {
	            session.setAttribute("mesg", "Invalid Email & Mobile Number");
	            session.removeAttribute("mesg");
	            return "adminForgot_Password";
	        }
	    }

	    @PostMapping("/adminChangePassword")
	    public String adminResetPassword(@RequestParam String password,
	                                     @RequestParam Long id, HttpSession session) {
	        Admin admin = adminRepo.findById(id).orElse(null);

	        if (admin != null) {
	            // Set the new password and save the admin
	            admin.setPassword(passwordEncode.encode(password));
	            Admin updatedAdmin = adminRepo.save(admin);

	            if (updatedAdmin != null) {
	                session.setAttribute("message", "Password Change Successfully!");
	            } else {
	                session.setAttribute("message", "Failed to change password. Please try again.");
	            }
	        } else {
	            session.setAttribute("message", "Admin not found.");
	        }

	        session.removeAttribute("message");
	        return "redirect:/adminloadForgotPassword";
	    }
}

