package com.project.Repositories;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.project.Entity.BudgetManagement;
import com.project.Entity.Expense;
import com.project.Entity.Income;
import com.project.Entity.User;

@Repository
public interface ExpenseRepository extends JpaRepository<Expense, Long> {

	public List<Expense> findByUser(User user);
	
	public List<Expense> findByUserId(Long userId);

	public List<Expense> getAllIncomesByUser(User user);

	@Query("SELECT SUM(e.amount) FROM Expense e WHERE e.user = :user")
    BigDecimal getTotalExpenses(@Param("user") User user);

}
