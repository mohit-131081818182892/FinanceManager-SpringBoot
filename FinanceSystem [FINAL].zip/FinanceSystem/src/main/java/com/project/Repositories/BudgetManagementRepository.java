package com.project.Repositories;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.project.Entity.BudgetManagement;
import com.project.Entity.User;

@Repository
public interface BudgetManagementRepository extends JpaRepository<BudgetManagement, Long> {

	public List<BudgetManagement> findByUser(User user);

    public List<BudgetManagement> findByUserId(Long userId);
    
    public List<BudgetManagement> findAll();

    public Optional<BudgetManagement> findById(Long id);

    public BudgetManagement save(BudgetManagement budget);

    void deleteById(Long id);

    @Query("SELECT SUM(b.limitAmount) FROM BudgetManagement b")
    public BigDecimal getTotalBudgetLimit();

}
