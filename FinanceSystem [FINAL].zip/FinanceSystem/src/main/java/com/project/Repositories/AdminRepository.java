package com.project.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.project.Entity.Admin;

@Repository
public interface AdminRepository extends JpaRepository<Admin, Long> {
    
public Admin findByUsername(String username);
    
    public Admin findByEmail(String email);
    
    public Admin findByEmailAndMobileNumber(String email, String mobileNumber);

    public Admin findByVerificationCode(String code);
    
    public boolean existsByUsername(String username);

    public boolean existsByEmail(String email);
}
