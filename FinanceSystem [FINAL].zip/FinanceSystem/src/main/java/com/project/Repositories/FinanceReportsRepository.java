package com.project.Repositories;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.project.Entity.FinanceReports;
@Repository
public interface FinanceReportsRepository extends JpaRepository<FinanceReports, Long>{

	// Custom query method to find finance reports by user ID
    public List<FinanceReports> findByUserId(Long userId);

    // Custom query method to find finance reports by type and within a date range
    public List<FinanceReports> findByTypeAndStartDateBetween(String type, LocalDate startDate, LocalDate endDate);

    // Custom query method to find finance reports by user ID and type
    public List<FinanceReports> findByUserIdAndType(Long userId, String type);

    // Custom query method to find finance reports by user ID and end date after a specific date
    public List<FinanceReports> findByUserIdAndEndDateAfter(Long userId, LocalDate endDate);
}
